// Simple AES-GCM implementation using Web Crypto API

async function getPasswordKey(password: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"]
  );
  return window.crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: enc.encode("salt_must_be_constant_for_demo"), // In production, use random salt
      iterations: 100000,
      hash: "SHA-256"
    },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function encryptFile(file: File, password: string): Promise<Blob> {
  const key = await getPasswordKey(password);
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const fileBuffer = await file.arrayBuffer();
  
  const encryptedContent = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv },
    key,
    fileBuffer
  );

  // Store MIME type to preserve file format (e.g. webm, mov, avi)
  const mimeBytes = new TextEncoder().encode(file.type);
  const mimeLen = mimeBytes.length; // Assumes mime length < 255, which is standard

  // Layout: [1 byte: Mime Length] [N bytes: Mime String] [12 bytes: IV] [Encrypted Data]
  const totalLength = 1 + mimeLen + iv.length + encryptedContent.byteLength;
  const combinedData = new Uint8Array(totalLength);
  
  let offset = 0;
  combinedData[offset] = mimeLen;
  offset++;
  
  combinedData.set(mimeBytes, offset);
  offset += mimeLen;
  
  combinedData.set(iv, offset);
  offset += iv.length;
  
  combinedData.set(new Uint8Array(encryptedContent), offset);

  return new Blob([combinedData], { type: 'application/octet-stream' });
}

export async function decryptFile(encryptedBlob: Blob, password: string): Promise<Blob> {
  const key = await getPasswordKey(password);
  const buffer = await encryptedBlob.arrayBuffer();
  const data = new Uint8Array(buffer);
  
  let offset = 0;
  
  // Read MIME type
  const mimeLen = data[offset];
  offset++;
  
  const mimeBytes = data.slice(offset, offset + mimeLen);
  const mimeType = new TextDecoder().decode(mimeBytes);
  offset += mimeLen;
  
  // Read IV
  const iv = data.slice(offset, offset + 12);
  offset += 12;
  
  const encryptedContent = data.slice(offset);

  const decryptedContent = await window.crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv },
    key,
    encryptedContent
  );

  return new Blob([decryptedContent], { type: mimeType || 'video/mp4' });
}